package com.konling.study.diceroller

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var diceImage: ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        diceImage = findViewById(R.id.dice_image)
        var rollbutton: Button = findViewById(R.id.roll_button)
        rollbutton.setOnClickListener { rollDice() }

    }

    private fun rollDice() {
        var randomInt = (1..6).random();
        Toast.makeText(this, "button clicked", Toast.LENGTH_SHORT).show();
//        var resultText : TextView = findViewById(R.id.result_text)
//        resultText.text = randomInt.toString()


        var drawableResource = when (randomInt) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }
        diceImage.setImageResource(drawableResource)

    }
}